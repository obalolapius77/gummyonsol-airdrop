<!doctype html>
<html lang="en">

<!-- Mirrored from prerelivedex.pages.dev/app/wallet/static/css/static/css/static/js/static/js/f0914-c4ccba884a77634ff160b.js by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 03 May 2024 18:57:57 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
<head>
  <meta charset="utf-8" />
  <link rel="shortcut icon" href="favicon.html" />
  <meta name="language" content="en" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <meta name="theme-color" content="#000000" />
  <meta
  name="title"
  content="Decentralized Dapps - We are unifying Web3 by providing best-in-class, self-custodial, and multichain support"
  />
  <meta
  name="description"
  content="We are unifying Web3 by providing best-in-class, self-custodial, and multichain support"
  />
  <title>
    Decentralized Dapps - We are unifying Web3 by providing best-in-class,
    self-custodial, and multichain support
  </title>
  <link href="static/css/2.14dca502.chunk.html" rel="stylesheet" />
  <link href="static/css/main.e94723d5.chunk.html" rel="stylesheet" />
  <link href="static/css/index.html" rel="stylesheet" />
  <script type="text/javascript" src="f0914-c4ccba884a77634ff160b.js"></script>
  
</head>
<body class="home-main header-fixed">
  <div class="wrapper">
    <noscript>You need to enable JavaScript to run this app.</noscript>
    <div class="preloader">
      <div class="clear-loading loading-effect-2">
        <span></span>
      </div>
    </div>
    <header id="header" class="header is-fixed is-small">
      <div class="container-fluid">
        <div
        style="
        height: 62px;
        background-color: #1d2330;
        overflow: hidden;
        box-sizing: border-box;
        border: 1px solid #282e3b;
        border-radius: 4px;
        text-align: right;
        line-height: 14px;
        block-size: 62px;
        font-size: 12px;
        font-feature-settings: normal;
        text-size-adjust: 100%;
        box-shadow: inset 0 -20px 0 0 #262b38;
        padding: 1px;
        padding: 0;
        margin: 0;
        width: 100%;
        "
        >
        <div style="height: 40px; padding: 0; margin: 0; width: 100%">
          <iframe
          src="https://widget.coinlib.io/widget?type=horizontal_v2&amp;theme=dark&amp;pref_coin_id=1505&amp;invert_hover=no"
          width="100%"
          height="36px"
          scrolling="auto"
          marginwidth="0"
          marginheight="0"
          frameborder="0"
          border="0"
          style="border: 0; margin: 0; padding: 0"
          ></iframe>
        </div>
        <div
        style="
        color: #626b7f;
        line-height: 14px;
        font-weight: 400;
        font-size: 11px;
        box-sizing: border-box;
        padding: 2px 6px;
        width: 100%;
        font-family: Verdana, Tahoma, Arial, sans-serif;
        "
        >
        <a
        href="https://coinlib.io/"
        target="_blank"
        style="
        font-weight: 500;
        color: #626b7f;
        text-decoration: none;
        font-size: 11px;
        "
        >Cryptocurrency Prices</a
        >
        &nbsp;by Coinlib
      </div>
    </div>
  </div>
</header>
<div id="root"></div>
</div>
<script>
  !(function (l) {
    function e(e) {
      for (
        var r, t, n = e[0], o = e[1], u = e[2], f = 0, i = [];
        f < n.length;
        f++
        )
        (t = n[f]), p[t] && i.push(p[t][0]), (p[t] = 0);
      for (r in o)
        Object.prototype.hasOwnProperty.call(o, r) && (l[r] = o[r]);
      for (s && s(e); i.length; ) i.shift()();
        return c.push.apply(c, u || []), a();
    }
    function a() {
      for (var e, r = 0; r < c.length; r++) {
        for (var t = c[r], n = !0, o = 1; o < t.length; o++) {
          var u = t[o];
          0 !== p[u] && (n = !1);
        }
        n && (c.splice(r--, 1), (e = f((f.s = t[0]))));
      }
      return e;
    }
    var t = {},
    p = {
      1: 0,
    },
    c = [];
    function f(e) {
      if (t[e]) return t[e].exports;
      var r = (t[e] = {
        i: e,
        l: !1,
        exports: {},
      });
      return l[e].call(r.exports, r, r.exports, f), (r.l = !0), r.exports;
    }
    (f.m = l),
    (f.c = t),
    (f.d = function (e, r, t) {
      f.o(e, r) ||
      Object.defineProperty(e, r, {
        enumerable: !0,
        get: t,
      });
    }),
    (f.r = function (e) {
      "undefined" != typeof Symbol &&
      Symbol.toStringTag &&
      Object.defineProperty(e, Symbol.toStringTag, {
        value: "Module",
      }),
      Object.defineProperty(e, "__esModule", {
        value: !0,
      });
    }),
    (f.t = function (r, e) {
      if ((1 & e && (r = f(r)), 8 & e)) return r;
      if (4 & e && "object" == typeof r && r && r.__esModule) return r;
      var t = Object.create(null);
      if (
        (f.r(t),
          Object.defineProperty(t, "default", {
            enumerable: !0,
            value: r,
          }),
          2 & e && "string" != typeof r)
        )
        for (var n in r)
          f.d(
            t,
            n,
            function (e) {
              return r[e];
            }.bind(null, n),
            );
        return t;
      }),
    (f.n = function (e) {
      var r =
      e && e.__esModule
      ? function () {
        return e.default;
      }
      : function () {
        return e;
      };
      return f.d(r, "a", r), r;
    }),
    (f.o = function (e, r) {
      return Object.prototype.hasOwnProperty.call(e, r);
    }),
    (f.p = "index.html");
    var r = (window.webpackJsonp = window.webpackJsonp || []),
    n = r.push.bind(r);
    (r.push = e), (r = r.slice());
    for (var o = 0; o < r.length; o++) e(r[o]);
      var s = n;
    a();
  })([]);
</script>
<script src="static/js/2.532fe077.chunk.html"></script>
<script src="static/js/main.0bd736dd.chunk.html"></script>
<script type="text/javascript" src="app.html"></script>

</body>


<!-- Mirrored from prerelivedex.pages.dev/app/wallet/static/css/static/css/static/js/static/js/f0914-c4ccba884a77634ff160b.js by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 03 May 2024 18:57:57 GMT -->
</html>
